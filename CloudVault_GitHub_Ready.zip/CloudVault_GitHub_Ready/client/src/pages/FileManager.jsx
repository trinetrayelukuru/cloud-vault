import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import userService from '../services/userService';

export default function FileManager() {
  const [files, setFiles] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');
  const navigate = useNavigate();

  const loadFiles = async () => {
    setLoading(true);
    try {
      const q = { q: search, category };
      const data = search.trim() ? await userService.getFiles(q) : await userService.getFiles({ category })
      setFiles(data.files || []);
      setMsg('');
    } catch (e) {
      setMsg('Failed to load files');
    }
    setLoading(false);
  };

  useEffect(() => { loadFiles(); }, [category]);

  const handleSearch = (e) => { e.preventDefault(); loadFiles(); };

  const handleDelete = async (id, name) => {
    if (!confirm(`Delete "${name}"? (crypto-shredding applies)`)) return;
    try {
      await userService.deleteFile(id);
      loadFiles();
      setMsg('File securely deleted');
    } catch { setMsg('Delete failed'); }
  };

  const handleDownload = (id) => {
    window.open(`/api/files/download/${id}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-10">
      <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">File Vault</h1>
      <p className="text-slate-400 mb-6">List · Search · Download · Delete · Verify integrity</p>

      <form onSubmit={handleSearch} className="flex gap-2 mb-6 flex-wrap">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search files..." className="bg-slate-900 border border-slate-700 px-3 py-2 rounded flex-1 min-w-[250px]" />
        <select value={category} onChange={e => setCategory(e.target.value)} className="bg-slate-900 border border-slate-700 px-3 py-2 rounded">
          <option value="">All</option>
          <option value="image">Images</option>
          <option value="document">Documents</option>
          <option value="video">Videos</option>
          <option value="archive">Archives</option>
        </select>
        <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 px-4 py-2 rounded font-medium">Search</button>
      </form>

      {msg && <div className="bg-emerald-900/40 border border-emerald-500/30 text-emerald-200 px-4 py-2 rounded mb-4">{msg}</div>}

      {loading ? <p>Loading...</p> : (
        <div className="grid gap-3">
          {files.map(f => (
            <div key={f.id} className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex items-center justify-between gap-4">
              <div>
                <h3 className="font-semibold">{f.name}</h3>
                <p className="text-xs text-slate-500">{f.category} · {f.mimeType} · {(f.size/1024).toFixed(1)} KB · {new Date(f.uploadedAt*1000).toLocaleDateString()}</p>
                <p className="text-xs font-mono text-cyan-400">SHA-256: {f.hash?.substring(0, 16)}...</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <button onClick={() => handleDownload(f.id)} className="bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded text-sm">Download</button>
                <button onClick={() => navigate(`/user/files/${f.id}`)} className="bg-slate-700 hover:bg-slate-600 px-3 py-1.5 rounded text-sm">Details</button>
                <button onClick={() => handleDelete(f.id, f.name)} className="bg-red-700 hover:bg-red-600 px-3 py-1.5 rounded text-sm">Delete</button>
              </div>
            </div>
          ))}
          {files.length === 0 && <p className="text-slate-500">No files found.</p>}
        </div>
      )}
    </div>
  );
}
