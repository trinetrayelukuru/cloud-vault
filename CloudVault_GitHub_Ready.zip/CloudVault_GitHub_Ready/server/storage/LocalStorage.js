const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const crypto = require('crypto');
const VaultCrypto = require('../utils/vaultCrypto');

class LocalStorage {
  constructor(basePath) {
    this.basePath = basePath || path.join(__dirname, '../../cloud-vault-storage');
    this.categories = {
      image: 'images',
      document: 'documents',
      video: 'videos',
      archive: 'archives',
      other: 'other'
    };
    // Secure temp directory for atomic writes
    this.tempDir = path.join(this.basePath, '.vault_temp');
  }

  // Initialize storage directories including secure temp
  async initialize() {
    try {
      await fs.mkdir(this.basePath, { recursive: true });

      // Create category directories
      for (const category of Object.values(this.categories)) {
        await fs.mkdir(path.join(this.basePath, category), { recursive: true });
      }

      // Create secure temp directory with restricted permissions
      await fs.mkdir(this.tempDir, { recursive: true });
      // Set restrictive permissions on temp dir (rwx------)
      try {
        await fs.chmod(this.tempDir, 0o700);
      } catch (e) {
        // chmod may not work on all platforms; continue silently
      }

      // Create .htaccess-like marker to prevent directory listing
      const markerPath = path.join(this.basePath, '.vault_secure');
      await fs.writeFile(markerPath, 'Cloud Vault Secure Storage\nDo not access directly.\n', { flag: 'w' });

      // Set restrictive permissions on marker
      try {
        await fs.chmod(markerPath, 0o600);
      } catch (e) { /* ignore */ }

      console.log('🔒 Secure Local Storage initialized (AES-256-GCM encrypted):', this.basePath);
      console.log('   🔐 Per-user encryption keys: ENABLED');
      console.log('   📁 Encrypted filenames: ENABLED');
      console.log('   ⚛️  Atomic writes: ENABLED');
      console.log('   🗑️  Crypto-shredding: ENABLED');
      console.log('   🔍 Integrity verification: ENABLED');
      return true;
    } catch (err) {
      console.error('❌ Failed to initialize local storage:', err);
      throw err;
    }
  }

  // Get storage path for user and category
  getUserStoragePath(userId, category) {
    const categoryFolder = this.categories[category] || this.categories.other;
    return path.join(this.basePath, categoryFolder, userId.toString());
  }

  // Ensure user directory exists
  async ensureUserDirectory(userId, category) {
    const userPath = this.getUserStoragePath(userId, category);
    await fs.mkdir(userPath, { recursive: true });
    return userPath;
  }

  /**
   * Generate a unique per-file salt for layered key derivation.
   * Each file gets its own salt stored alongside the encrypted data.
   */
  generateFileSalt() {
    return crypto.randomBytes(16).toString('hex');
  }

  /**
   * Store file securely with AES-256-GCM encryption-at-rest.
   * Uses per-user key derivation and encrypted filenames.
   * Plaintext never touches the disk.
   * Atomic write pattern: write to temp, then rename.
   *
   * @param {number} userId - User ID for per-key encryption
   * @param {string} category - File category
   * @param {string} storedFilename - Original stored filename
   * @param {Buffer} plaintextBuffer - File data to encrypt
   * @param {Object} options - Additional options
   * @returns {Object} Storage result with encrypted path, hash, salt
   */
  async storeFile(userId, category, storedFilename, plaintextBuffer, options = {}) {
    try {
      // Get user's derived encryption key
      const userKey = options.userKey || await this.getUserKey(userId);

      if (!userKey) {
        throw new Error('No encryption key available for user. Please re-authenticate.');
      }

      const userPath = await this.ensureUserDirectory(userId, category);

      // Encrypt the filename on disk
      const encryptedFilename = VaultCrypto.encryptFilename(storedFilename, userKey);

      // Generate per-file salt
      const fileSalt = this.generateFileSalt();

      // Derive file-specific key from user key + salt
      const fileKey = VaultCrypto.deriveFileKey(userKey, fileSalt);

      // Generate full encrypted path
      const filePath = path.join(userPath, encryptedFilename + '.enc');
      const tempFilePath = path.join(this.tempDir, `${crypto.randomBytes(8).toString('hex')}.tmp`);

      // Encrypt the file buffer using per-user key
      const encryptedEnvelope = VaultCrypto.encrypt(plaintextBuffer, {
        userKey,
        salt: fileSalt
      });

      // Calculate SHA-256 of plaintext for integrity verification
      const sha256Hash = VaultCrypto.calculateHash(plaintextBuffer);

      // ATOMIC WRITE: Write to temp file first, then rename
      await fs.writeFile(tempFilePath, encryptedEnvelope);

      // Set restrictive permissions on temp file
      try {
        await fs.chmod(tempFilePath, 0o600);
      } catch (e) { /* ignore */ }

      // Atomic rename (temp → final)
      await fs.rename(tempFilePath, filePath);

      // Set restrictive permissions on final encrypted file
      try {
        await fs.chmod(filePath, 0o600);
      } catch (e) { /* ignore */ }

      return {
        success: true,
        storagePath: filePath,
        encryptedFilename,
        isEncrypted: true,
        algorithm: 'aes-256-gcm',
        storedBytes: encryptedEnvelope.length,
        originalBytes: plaintextBuffer.length,
        sha256Hash,
        fileSalt,
        userId
      };
    } catch (err) {
      // Clean up temp file on error
      await this._cleanupTempFile(err);
      console.error('Secure store file error:', err);
      throw new Error(`Failed to securely store file: ${err.message}`);
    }
  }

  /**
   * Retrieve and decrypt a file from secure storage.
   * If raw: true is passed, returns the raw encrypted envelope without decrypting.
   * Logs access for audit trail.
   *
   * @param {string} storagePath - Path to encrypted file
   * @param {Object} options - { userId, userKey, raw, fileId }
   * @returns {Buffer} Decrypted plaintext buffer or raw encrypted buffer
   */
  async retrieveFile(storagePath, options = {}) {
    try {
      const fileBuffer = await fs.readFile(storagePath);

      if (options.raw) {
        return fileBuffer;
      }

      const userId = options.userId;
      const userKey = options.userKey || (userId ? await this.getUserKey(userId) : null);

      if (!userKey) {
        throw new Error('No encryption key available for decryption. Please re-authenticate.');
      }

      // Log file access
      if (options.fileId && userId) {
        await this.logFileAccess(options.fileId, userId, 'DOWNLOAD', options.ipAddress, options.userAgent, true);
      }

      // Check if file is encrypted envelope
      if (VaultCrypto.isEncrypted(fileBuffer)) {
        const decrypted = VaultCrypto.decrypt(fileBuffer, { userKey });

        // Verify integrity if SHA-256 hash is available
        if (options.expectedHash) {
          const actualHash = VaultCrypto.calculateHash(decrypted);
          if (actualHash !== options.expectedHash) {
            // Log integrity failure
            if (options.fileId && userId) {
              await this.logFileAccess(options.fileId, userId, 'INTEGRITY_FAIL', options.ipAddress, options.userAgent, false);
            }
            throw new Error('File integrity verification failed! The file may have been tampered with.');
          }
        }

        return decrypted;
      }

      // Fallback for unencrypted legacy files if any
      return fileBuffer;
    } catch (err) {
      // Log failed access attempt
      if (options.fileId && options.userId) {
        await this.logFileAccess(options.fileId, options.userId, 'DOWNLOAD_FAIL', options.ipAddress, options.userAgent, false);
      }
      console.error('Retrieve file error:', err);
      throw new Error(`Failed to retrieve/decrypt file: ${err.message}`);
    }
  }

  /**
   * Securely delete a file using crypto-shredding.
   * Overwrites the file with random data before deletion,
   * then removes it. This makes recovery practically impossible.
   *
   * @param {string} storagePath - Path to encrypted file
   * @param {Object} options - { userId, fileId, userKey }
   * @returns {Object} Deletion result
   */
  async deleteFile(storagePath, options = {}) {
    try {
      // Verify file exists first
      const exists = await this.fileExists(storagePath);
      if (!exists) {
        return { success: true, alreadyDeleted: true };
      }

      // Get file stats for logging
      const stats = await fs.stat(storagePath);
      const originalSize = stats.size;

      // Secure overwrite: Write random data over the file before deletion
      // This prevents forensic recovery of the encrypted data
      await this._secureOverwrite(storagePath);

      // Delete the file
      await fs.unlink(storagePath);

      // Log secure deletion
      if (options.fileId && options.userId) {
        await this.logFileAccess(
          options.fileId,
          options.userId,
          'DELETE',
          options.ipAddress,
          options.userAgent,
          true,
          `Securely deleted ${originalSize} bytes with crypto-shredding`
        );
      }

      return {
        success: true,
        bytesSecurelyDeleted: originalSize,
        method: 'crypto-shredding + overwrite'
      };
    } catch (err) {
      console.error('Secure delete error:', err);
      // Attempt regular deletion if secure overwrite fails
      try {
        await fs.unlink(storagePath);
      } catch (e) { /* ignore */ }
      throw new Error(`Failed to securely delete file: ${err.message}`);
    }
  }

  /**
   * Check if file exists
   */
  async fileExists(storagePath) {
    try {
      await fs.access(storagePath);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Get file stats (encrypted file stats)
   */
  async getFileStats(storagePath) {
    try {
      const stats = await fs.stat(storagePath);
      return {
        size: stats.size,
        created: stats.birthtime,
        modified: stats.mtime,
        accessed: stats.atime
      };
    } catch (err) {
      throw new Error(`Failed to get file stats: ${err.message}`);
    }
  }

  /**
   * Verify file at rest has not been tampered with.
   * Decrypts and compares SHA-256 hash against stored hash.
   *
   * @param {string} storagePath - Path to encrypted file
   * @param {Object} options - { userId, userKey, expectedSha256 }
   * @returns {Object} Verification result
   */
  async verifyFileIntegrity(storagePath, options = {}) {
    try {
      const encryptedBuffer = await fs.readFile(storagePath);
      if (!VaultCrypto.isEncrypted(encryptedBuffer)) {
        return { valid: false, reason: 'File is not encrypted with Cloud Vault envelope.' };
      }

      const userId = options.userId;
      const userKey = options.userKey || (userId ? await this.getUserKey(userId) : null);

      if (!userKey) {
        return { valid: false, reason: 'No encryption key available for verification.' };
      }

      // Decrypt to verify GCM authentication tag + SHA-256
      const decrypted = VaultCrypto.decrypt(encryptedBuffer, { userKey });
      const actualHash = VaultCrypto.calculateHash(decrypted);

      const expectedHash = options.expectedSha256;
      const hashMatch = expectedHash ? (actualHash === expectedHash) : true;

      return {
        valid: hashMatch,
        sha256: actualHash,
        expectedSha256: expectedHash,
        hashMatch,
        size: decrypted.length,
        algorithm: 'aes-256-gcm'
      };
    } catch (err) {
      return {
        valid: false,
        reason: err.message
      };
    }
  }

  /**
   * Verify multiple files integrity at once
   */
  async verifyAllUserFiles(userId, files) {
    const userKey = await this.getUserKey(userId);
    if (!userKey) {
      throw new Error('No encryption key available.');
    }

    const results = [];
    for (const file of files) {
      try {
        const result = await this.verifyFileIntegrity(file.storage_path, {
          userId,
          userKey,
          expectedSha256: file.sha256_hash
        });
        results.push({
          fileId: file.id,
          fileName: file.original_filename,
          ...result
        });
      } catch (err) {
        results.push({
          fileId: file.id,
          fileName: file.original_filename,
          valid: false,
          reason: err.message
        });
      }
    }
    return results;
  }

  /**
   * Get user's encryption key from memory or derive from DB salt
   */
  async getUserKey(userId) {
    // Check in-memory session cache first
    const cachedKey = await this._getCachedKey(userId);
    if (cachedKey) {
      return cachedKey;
    }

    // Derive from DB-stored salt
    const userRecord = await this._getUserRecord(userId);
    if (!userRecord || !userRecord.encryption_salt) {
      return null;
    }

    const userKey = VaultCrypto.deriveUserKey(userRecord.encryption_salt);

    // Cache in memory for session
    this._cacheKey(userId, userKey);

    return userKey;
  }

  /**
   * Get encryption salt from database for a user
   * This is called by getFileKey and retrieveFile when needed
   */
  async _getUserRecord(userId) {
    // Direct DB query since we need encryption key info
    const { getQuery } = require('../config/database');
    const sql = `
      SELECT ek.salt AS encryption_salt, u.id
      FROM users u
      JOIN encryption_keys ek ON u.id = ek.user_id
      WHERE u.id = ? AND u.account_status = 'active'
      ORDER BY ek.created_at DESC
      LIMIT 1
    `;
    return await getQuery(sql, [userId]);
  }

  // In-memory key cache (process-level, not persisted)
  _keyCache = new Map();

  _getCachedKey(userId) {
    const entry = this._keyCache.get(userId);
    if (!entry) return null;
    if (Date.now() - entry.timestamp > 30 * 60 * 1000) {
      this._keyCache.delete(userId);
      return null;
    }
    return entry.key;
  }

  _cacheKey(userId, key) {
    this._keyCache.set(userId, { key, timestamp: Date.now() });
  }

  /**
   * Securely overwrite a file with random data before deletion
   */
  async _secureOverwrite(storagePath) {
    try {
      const stats = await fs.stat(storagePath);
      const fileSize = stats.size;

      // Overwrite with random data 3 times (US DoD 5220.22-M standard)
      for (let i = 0; i < 3; i++) {
        const randomData = crypto.randomBytes(fileSize);
        await fs.writeFile(storagePath, randomData);
        // Sync to disk to ensure write completes
        await fsSync.promises.sync(storagePath);
      }
    } catch (err) {
      // If overwrite fails (e.g., permissions), continue with deletion
      console.warn('Secure overwrite warning:', err.message);
    }
  }

  /**
   * Log file access for audit trail
   */
  async logFileAccess(fileId, userId, action, ipAddress, userAgent, success, details = '') {
    try {
      const { runQuery } = require('../config/database');
      await runQuery(
        `INSERT INTO file_access_log (file_id, user_id, action, ip_address, user_agent, success, details) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [fileId, userId, action, ipAddress, userAgent, success ? 1 : 0, details]
      );
    } catch (err) {
      console.error('Failed to log file access:', err.message);
    }
  }

  /**
   * Get access log for a file
   */
  async getFileAccessLog(fileId, limit = 50) {
    try {
      const { allQuery } = require('../config/database');
      const sql = `
        SELECT fal.id, fal.action, fal.success, fal.details, fal.timestamp,
               u.name as user_name, u.email as user_email
        FROM file_access_log fal
        LEFT JOIN users u ON fal.user_id = u.id
        WHERE fal.file_id = ?
        ORDER BY fal.timestamp DESC
        LIMIT ?
      `;
      return await allQuery(sql, [fileId, limit]);
    } catch (err) {
      console.error('Failed to get file access log:', err.message);
      return [];
    }
  }

  /**
   * Clean up temp file on error
   */
  async _cleanupTempFile(err) {
    // Temp file path isn't always available from the error
    // The temp directory is cleaned periodically
  }

  /**
   * Clean up expired temp files (run periodically)
   */
  async cleanupTempFiles() {
    try {
      const files = await fs.readdir(this.tempDir);
      const now = Date.now();
      const maxAge = 60 * 60 * 1000; // 1 hour max age

      for (const file of files) {
        const filePath = path.join(this.tempDir, file);
        try {
          const stats = await fs.stat(filePath);
          if (now - stats.birthtimeMs > maxAge) {
            // Secure overwrite before deletion
            await this._secureOverwrite(filePath);
            await fs.unlink(filePath);
          }
        } catch (e) { /* skip */ }
      }
    } catch (err) {
      console.error('Temp file cleanup error:', err.message);
    }
  }

  // Get storage usage for user
  async getUserStorageUsage(userId) {
    let totalSize = 0;
    let fileCount = 0;

    for (const category of Object.values(this.categories)) {
      const userPath = path.join(this.basePath, category, userId.toString());

      try {
        const files = await fs.readdir(userPath);

        for (const file of files) {
          const filePath = path.join(userPath, file);
          // Only count .enc files (encrypted storage)
          if (!file.endsWith('.enc') && file !== '.vault_secure') continue;
          const stats = await fs.stat(filePath);
          totalSize += stats.size;
          fileCount++;
        }
      } catch (err) {
        continue;
      }
    }

    return { totalSize, fileCount };
  }

  /**
   * Get all encrypted files for a user (for admin auditing - metadata only)
   */
  async getAllUserFiles(userId) {
    const files = [];
    for (const category of Object.values(this.categories)) {
      const userPath = path.join(this.basePath, category, userId.toString());
      try {
        const entries = await fs.readdir(userPath);
        for (const entry of entries) {
          if (entry.endsWith('.enc') && entry !== '.vault_secure') {
            const filePath = path.join(userPath, entry);
            const stats = await fs.stat(filePath);
            files.push({
              filename: entry,
              category,
              size: stats.size,
              path: filePath,
              encrypted: true
            });
          }
        }
      } catch (e) { /* skip */ }
    }
    return files;
  }
}

module.exports = LocalStorage;
